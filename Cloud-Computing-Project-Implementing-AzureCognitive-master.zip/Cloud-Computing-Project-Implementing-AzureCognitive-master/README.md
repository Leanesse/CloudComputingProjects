 CMPE363 Junior project
 **********************
 
 In this project, a simple webapp is made using Python Flask. Implementing Microsoft Azure Cognitive services, specifically speech services.
 
 Then, It was deployed on Azure Portal for testing.
 
 
